<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Revelation Manager. Brought to you by <a href="http://bravosoft.ng">Bravosoft</a> </div>
</div>