<div id="sidebar"><a href="<?php echo e(url ('home')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="<?php echo e(Request::is ('home') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('home')); ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li class="submenu <?php echo e(Request::is ('member', 'member/create') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-user"></i> <span>Members</span></a>
    <!-- <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Follow Ups</span> <span class="label label-important">3</span></a> -->
      <ul>
        <li class="<?php echo e(Request::is ('member') ?  'active'  : ''); ?>"><a href="<?php echo e(route ('member.index')); ?>">View Members</a></li>
        <li class="<?php echo e(Request::is ('member/create') ?  'active'  : ''); ?>"><a href="<?php echo e(route ('member.create')); ?> ">Add Members</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('headofdepartment', 'headofdepartment/create') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-cog"></i> <span>HeadOfDepartments</span></a>
    <ul>
        <li class="<?php echo e(Request::is ('headofdepatment') ?  'active'  : ''); ?>"><a href="<?php echo e(route ('headofdepartment.index')); ?>">View HeadOfDepartment</a></li>
        <li class="<?php echo e(Request::is ('headofdepatment/create') ?  'active'  : ''); ?>"><a href="<?php echo e(route ('headofdepartment.create')); ?> ">Add HeadOfDepartment</a></li>
      </ul>
    </li>
    <li class= "submenu <?php echo e(Request::is ('events', 'event/create') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-inbox"></i> <span>Events</span></a>
    <ul>
        <li class="<?php echo e(Request::is ('events') ?  'active'  : ''); ?>"><a href="<?php echo e(route ('events.index')); ?>">View Events</a></li>
        <li class="<?php echo e(Request::is ('event/create') ?  'active'  : ''); ?>"><a href="<?php echo e(route ('events.create')); ?> ">Add Events</a></li>
         <!-- <li><a href="<?php echo e(route ('events.create')); ?> ">Manage Calender</a></li> -->
      </ul>
    </li>
     <li class="submenu <?php echo e(Request::is ('campaign', 'campaign/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-th"></i> <span>Campaigns</span></a>
    <ul>
        <li><a href="<?php echo e(route ('campaign.index')); ?>">All Campaign</a></li>
        <li><a href="<?php echo e(route ('campaign.create')); ?> ">Add Campaign</a></li>
    </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('pledge', 'pledge/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-th"></i> <span>Pledges</span></a>
    <ul>
        <li><a href="<?php echo e(route ('pledge.index')); ?>">View Pledges</a></li>
        <li><a href="<?php echo e(route ('pledge.create')); ?>">Add Pledges</a></li>
    </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('contribution', 'contribution/create', 'funds', 'funds/create', 'payment/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-fullscreen"></i> <span>Contributions</span></a>
    <ul>
        <li><a href="<?php echo e(route ('contribution.index')); ?>">View Contributions</a></li>
        <li><a href="<?php echo e(route ('contribution.create')); ?> ">Add Contribution</a></li>
        <li><a href="<?php echo e(route ('funds.index')); ?> ">Manage Funds</a></li>
          <li><a href="<?php echo e(route ('payment.create')); ?> ">Manage Payment Methods</a></li>
    </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('followup', 'followupcategory', 'followup/create') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-th-list"></i> <span>Follow Ups</span> <span class="label label-important">3</span></a>
      <ul>
        <li><a href="<?php echo e(route ('followup.index')); ?>">View Follow ups</a></li>
        <li><a href="<?php echo e(url ('followup/followupcategory')); ?>">My Follow ups</a></li>
        <li><a href="<?php echo e(route ('followupcategory.index')); ?>">Manage Expenses Type</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('expense', 'expense/data', 'expense/create', 'expensetype') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-th-list"></i> <span>Expenses</span> <span class="label label-important">3</span></a>
      <ul>
        <li><a href="<?php echo e(route ('expense.index')); ?>">View Expenses</a></li>
        <li><a href="<?php echo e(route ('expense.create')); ?>">Add Expenses</a></li>
        <li><a href="<?php echo e(route ('expensetype.index')); ?>">Manage Expenses Type</a></li>
      </ul>
    </li>
   <!--  <li class="submenu <?php echo e(Request::is ('contribution', 'contribution/create', 'funds', 'funds/create', 'payment/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-fullscreen"></i> <span>Contributions</span></a>
    <ul>
        <li><a href="<?php echo e(route ('contribution.index')); ?>">View Expenses</a></li>
        <li><a href="<?php echo e(route ('contribution.create')); ?> ">Add Expenses</a></li>
        <li><a href="<?php echo e(route ('funds.index')); ?> ">Manage Funds</a></li>
          <li><a href="<?php echo e(route ('payment.create')); ?> ">Manage Payment Methods</a></li>
    </ul>
    </li> -->
    <li class="submenu <?php echo e(Request::is ('payroll', 'payroll/create', 'staff', 'staff/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-tint"></i> <span>Payroll</span></a>
      <ul>
        <li><a href="<?php echo e(route ('payroll.index')); ?>">View Payroll</a></li>
        <li><a href="<?php echo e(route ('payroll.create')); ?>">Add Payroll</a></li>
        <li><a href="<?php echo e(route ('staff.index')); ?>">Manage Staff</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('reports') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-tint"></i> <span>Reports</span></a>
      <ul>
        <li><a href="<?php echo e(url ('payroll/data')); ?>">Cash Flow</a></li>
        <li><a href="#">Profit / Loss</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('assets/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-pencil"></i> <span>Assets</span></a>
      <ul>
        <li><a href="<?php echo e(url ('followup/data')); ?>">View Assets</a></li>
        <li><a href="#">Add Asset</a></li>
        <li><a href="#">Manage Asset Types</a></li>
     </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('email/create', 'email', 'sms/create', 'sms') ?  'active'  : ''); ?>"> <a href="#"><i class="icon icon-file"></i> <span>Messaging</span> <span class="label label-important">5</span></a>
      <ul>
        <li><a href="<?php echo e(route ('email.index')); ?>">Email</a></li>
        <li><a href="<?php echo e(route ('sms.index')); ?>">SMS</a></li>
      </ul>
    </li>
    <li class= "<?php echo e(Request::is ('settings') ?  'active'  : ''); ?>"> <a href="#"><i class="icon icon-info-sign"></i> <span>Settings</span> <span class="label label-important">4</span></a>
    </li>
    <li "<?php echo e(Request::is ('logged', 'logged/index') ?  'active'  : ''); ?>"> <a href="<?php echo e(route ('logged.index')); ?>"><i class="icon icon-fullscreen"></i> <span>Login Info</span></a></li>
  </ul>
</div>