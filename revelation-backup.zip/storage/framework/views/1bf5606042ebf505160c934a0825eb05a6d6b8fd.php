<!DOCTYPE html>
<html lang="en">
<head>
<title>Revelation Manager</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/bootstrap-responsive.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/uniform.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/select2.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/matrix-style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/matrix-media.css')); ?>" />
<link href="<?php echo e(asset('resources/assets/back/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
  <style>
      .pagination li{
        display:inline;
      }
  </style>

<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Revelation Manager</a></h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->


<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Login User Tables</a> </div>
  </div>
  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
      
        
        
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Login users table</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Notes</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $loginuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loginusers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
           
                <tr class="gradeX">
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td><?php echo e($loginusers->user); ?></td>
                  <td><?php echo e($loginusers->notes); ?></td>
                  
                  <td><?php echo e($loginusers->created_at); ?></td>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--Footer-part-->

<!--end-Footer-part-->
<script src="<?php echo e(asset('resources/assets/back/js/jquery.min.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/jquery.ui.custom.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/assets/back/js/jquery.uniform.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/assets/back/js/jquery.dataTables.min.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/matrix.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/matrix.tables.js')); ?>"></script>
</body>
</html>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('auth.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>