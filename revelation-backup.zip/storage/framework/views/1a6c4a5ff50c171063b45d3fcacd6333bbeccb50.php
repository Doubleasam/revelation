<!DOCTYPE html>
<html lang="en">
<head>
<title>Matrix Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/bootstrap-responsive.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/fullcalendar.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/matrix-style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('resources/assets/back/css/matrix-media.css')); ?>" />
<link href="<?php echo e(asset('resources/assets/back/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Revelation Manager</a></h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->


<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="<?php echo e(url ('home2')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="<?php echo e(Request::is ('home') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('home')); ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li class="submenu<?php echo e(Request::is ('/member') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-signal"></i> <span>Members</span></a>
    <!-- <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Follow Ups</span> <span class="label label-important">3</span></a> -->
      <ul>
        <li><a href="<?php echo e(route ('member.index')); ?>">View Members</a></li>
        <li><a href="<?php echo e(route ('member.create')); ?> ">Add Members</a></li>
      </ul>
    </li>
    <li class= "submenu <?php echo e(Request::is ('events/create') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-inbox"></i> <span>Events</span></a>
    <ul>
        <li><a href="<?php echo e(route ('events.index')); ?>">View Events</a></li>
        <li><a href="<?php echo e(route ('events.create')); ?> ">Add Events</a></li>
         <!-- <li><a href="<?php echo e(route ('events.create')); ?> ">Manage Calender</a></li> -->
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('pledge/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-th"></i> <span>Pledges</span></a>
    <ul>
        <li><a href="<?php echo e(route ('member.index')); ?>">View Pledges</a></li>
        <li><a href="<?php echo e(route ('member.create')); ?> ">Add Pledges</a></li>
        <li><a href="<?php echo e(route ('member.create')); ?> ">Manage Campaigns</a></li>
    </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('member/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-fullscreen"></i> <span>Contributions</span></a>
    <ul>
        <li><a href="<?php echo e(route ('member.index')); ?>">View Pledges</a></li>
        <li><a href="<?php echo e(route ('member.create')); ?> ">Add Pledges</a></li>
        <li><a href="<?php echo e(route ('member.create')); ?> ">Manage Campaigns</a></li>
    </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('followup/create') ?  'active'  : ''); ?>"> <a href="<?php echo e(url ('#')); ?>"><i class="icon icon-th-list"></i> <span>Follow Ups</span> <span class="label label-important">3</span></a>
      <ul>
        <li><a href="<?php echo e(route ('followup.index')); ?>">View Follow ups</a></li>
        <li><a href="form-validation.html">My Follow ups</a></li>
        <li><a href="form-wizard.html">Add Follow ups</a></li>
        <li><a href="form-wizard.html">Manage Follow up Categories</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('report/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-tint"></i> <span>Reports</span></a>
      <ul>
        <li><a href="<?php echo e(url ('followup/data')); ?>">Cash Flow</a></li>
        <li><a href="form-validation.html">Profit / Loss</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('assets/create') ?  'active'  : ''); ?>"><a href="<?php echo e(url ('#')); ?>"><i class="icon icon-pencil"></i> <span>Assets</span></a>
      <ul>
        <li><a href="<?php echo e(url ('followup/data')); ?>">View Assets</a></li>
        <li><a href="form-validation.html">Add Asset</a></li>
        <li><a href="form-wizard.html">Manage Asset Types</a></li>
     </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('message/create') ?  'active'  : ''); ?>"> <a href="#"><i class="icon icon-file"></i> <span>Messaging</span> <span class="label label-important">5</span></a>
      <ul>
        <li><a href="<?php echo e(url ('followup/data')); ?>">Email</a></li>
        <li><a href="form-validation.html">SMS</a></li>
      </ul>
    </li>
    <li class="submenu <?php echo e(Request::is ('user/create') ?  'active'  : ''); ?>"> <a href="#"><i class="icon icon-info-sign"></i> <span>Users</span> <span class="label label-important">4</span></a>
      <ul>
        <li><a href="error403.html">Error 403</a></li>
        <li><a href="error404.html">Error 404</a></li>
        <li><a href="error405.html">Error 405</a></li>
        <li><a href="error500.html">Error 500</a></li>
      </ul>
    </li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Login Info</span></a></li>
  </ul>
</div>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"><a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Sample pages</a> <a href="#" class="current">Calendar</a></div>
    <h1>Calendar</h1>
  </div>
  <div class="container-fluid">
    <hr>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box widget-calendar">
          <div class="widget-title"> <span class="icon"><i class="icon-calendar"></i></span>
            <h5>Calendar</h5>
            <div class="buttons"> <a id="add-event" data-toggle="modal" href="#modal-add-event" class="btn btn-inverse btn-mini"><i class="icon-plus icon-white"></i> Add new event</a>
              <div class="modal hide" id="modal-add-event">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">×</button>
                  <h3>Add a new event</h3>
                </div>
                <div class="modal-body">
                  <p>Enter test event name:</p>
                  <p>
                    <input id="event-name" type="text" />
                  </p>
                </div>
                <div class="modal-footer"> <a href="#" class="btn" data-dismiss="modal">Cancel</a> <a href="#" id="add-event-submit" class="btn btn-primary">Add event</a> </div>
              </div>
            </div>
          </div>
          <div class="widget-content">
            <div class="panel-left">
              <div id="fullcalendar"></div>
            </div>
            <div id="external-events" class="panel-right">
              <div class="panel-title">
                <h5>Drag Events to the calander</h5>
              </div>
              <div class="panel-content">
                <div class="external-event ui-draggable label label-inverse">My Event 1</div>
                <div class="external-event ui-draggable label label-inverse">My Event 2</div>
                <div class="external-event ui-draggable label label-inverse">My Event 3</div>
                <div class="external-event ui-draggable label label-inverse">My Event 4</div>
                <div class="external-event ui-draggable label label-inverse">My Event 5</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; Matrix Admin. Brought to you by <a href="http://themedesigner.in">Themedesigner.in</a> </div>
</div>
<!--end-Footer-part-->
<script src="<?php echo e(asset('resources/assets/back/js/jquery.min.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/jquery.ui.custom.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/assets/back/js/fullcalendar.min.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/matrix.js')); ?>"></script> 
<script src="<?php echo e(asset('resources/assets/back/js/matrix.calendar.js')); ?>"></script>


</body>
</html>
