<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FollowUpCategory extends Model
{
    protected $table = "follow_up_categories";

    public $timestamps = false;
}
