<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VolunteerRole extends Model
{
    protected $table = "volunteer_roles";

    public $timestamps = false;
}
