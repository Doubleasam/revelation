<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventCalendar extends Model
{
    protected $table = "event_calendars";

    public $timestamps = false;
}
