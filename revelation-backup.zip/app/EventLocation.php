<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventLocation extends Model
{
    protected $table = "event_locations";

    public $timestamps = false;
}
